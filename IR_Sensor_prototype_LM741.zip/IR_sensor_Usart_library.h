#ifndef IR_SENSOR_USART_LIBRARY_H
#define IR_SENSOR_USART_LIBRARY_H

#include "stm32f10x.h"

// UART yapilandirmasi
void IR_Sensor_UART_Init(void);

// UART �zerinden karakter g�nderme
void IR_Sensor_UART_SendChar(char c);

// UART �zerinden string g�nderme
void IR_Sensor_UART_SendString(char* str);

// ADC yapilandirmasi
void IR_Sensor_ADC_Init(void);

// ADC degerini okuma
uint16_t IR_Sensor_ADC_Read(void);

// ADC degerini UART �zerinden g�nderme
void IR_Sensor_Send_ADC_Value(void);

#endif // IR_SENSOR_USART_LIBRARY_H
